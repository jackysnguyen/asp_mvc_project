﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace quanlyfood.Models
{
    public class LoaiModel
    {
        public int MaLoai { get; set; }
        public string TenLoai { get; set; }
        
        

    }
}