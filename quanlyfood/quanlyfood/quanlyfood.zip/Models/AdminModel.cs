﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace quanlyfood.Models
{
    public class AdminModel
    {
        public string username;
        public string password;
        public string name;

    }
}